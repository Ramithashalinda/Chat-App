package com.example.my_chat_app.Fragments;

import androidx.lifecycle.ViewModel;

public class PeopleViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}