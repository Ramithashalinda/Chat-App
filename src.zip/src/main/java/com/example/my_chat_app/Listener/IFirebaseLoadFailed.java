package com.example.my_chat_app.Listener;

public interface IFirebaseLoadFailed {
    void onError(String message);
}
