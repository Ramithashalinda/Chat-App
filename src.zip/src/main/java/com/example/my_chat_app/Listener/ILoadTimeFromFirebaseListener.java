package com.example.my_chat_app.Listener;

public interface ILoadTimeFromFirebaseListener {

    void onLoadOnlyTimeSuccess(long estimateTimeInMs);

}
