package com.example.my_chat_app.Model;

public class FCMResult {
    private int message_id;

    public FCMResult() {
    }

    public int getMessage_id() {
        return message_id;
    }

    public void setMessage_id(int message_id) {
        this.message_id = message_id;
    }
}
