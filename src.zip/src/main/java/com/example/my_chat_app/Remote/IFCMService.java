package com.example.my_chat_app.Remote;

import com.example.my_chat_app.Model.FCMResponse;
import com.example.my_chat_app.Model.FCMSendData;

import io.reactivex.Observable;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface IFCMService {
    @Headers({
            "Content-Type:application/json",
            "Authorization:key=AAAAF_b4q-I:APA91bFOMN8arKHdSgfs6FgoFOhLOooOACA01VNnfbH4j3so2z6G-e93JjVi_T-vvKEQP1rIsapiW-U8gPQ1JDogA8oqs1L1fMdYr3Wl8cA0B6HCtFN_AVnAck7BsfG9q_OSt1-gUiIz"

    })
    @POST("fcm/send")
    Observable<FCMResponse> sendNotification(@Body FCMSendData body);
}
